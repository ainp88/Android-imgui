package com.android.imgui;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.os.Bundle;
import android.os.Handler;
import android.text.InputType;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.EditText;
import android.opengl.GLSurfaceView;
import javax.microedition.khronos.opengles.GL10;
import javax.microedition.khronos.egl.EGLConfig;

public class MainActivity extends Activity {
    static { System.loadLibrary("toim"); }

    private GLSurfaceView glSurfaceView;
    private View touchView;
    private WindowManager windowManager;
    private Handler handler;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        windowManager = getWindowManager();

        // 设置配置保存路径
        String configPath = getFilesDir().getAbsolutePath() + "/imguiconfig.cfg";
        nativeSetConfigPath(configPath);

        glSurfaceView = new GLSurfaceView(this);
        glSurfaceView.setEGLConfigChooser(8, 8, 8, 8, 16, 0);
        glSurfaceView.getHolder().setFormat(android.graphics.PixelFormat.TRANSLUCENT);
        glSurfaceView.setEGLContextClientVersion(3);
        glSurfaceView.setRenderer(new Renderer());
        glSurfaceView.setRenderMode(GLSurfaceView.RENDERMODE_CONTINUOUSLY);

        WindowManager.LayoutParams glP = new WindowManager.LayoutParams(
                WindowManager.LayoutParams.MATCH_PARENT,
                WindowManager.LayoutParams.MATCH_PARENT,
                WindowManager.LayoutParams.TYPE_APPLICATION,
                WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE |
                        WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
                android.graphics.PixelFormat.TRANSLUCENT);
        glP.gravity = Gravity.TOP | Gravity.LEFT;

        touchView = new View(this);
        WindowManager.LayoutParams tP = new WindowManager.LayoutParams(
                WindowManager.LayoutParams.MATCH_PARENT,
                WindowManager.LayoutParams.MATCH_PARENT,
                WindowManager.LayoutParams.TYPE_APPLICATION,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE |
                        WindowManager.LayoutParams.FLAG_SPLIT_TOUCH,
                android.graphics.PixelFormat.TRANSLUCENT);
        tP.gravity = Gravity.TOP | Gravity.LEFT;

        windowManager.addView(glSurfaceView, glP);
        windowManager.addView(touchView, tP);

        touchView.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent e) {
                int a = e.getActionMasked();
                boolean down = (a == MotionEvent.ACTION_DOWN ||
                               a == MotionEvent.ACTION_POINTER_DOWN ||
                               a == MotionEvent.ACTION_MOVE);
                nativeTouchEvent(down, e.getX(), e.getY());
                return true;
            }
        });

        handler = new Handler();
        handler.postDelayed(new Runnable() {
            @Override
            public void run() {
                if (nativeNeedShowInputDialog()) {
                    nativeSetNeedShowInputDialog(false);
                    showInputDialog();
                }
                handler.postDelayed(this, 100);
            }
        }, 100);
    }

    private void showInputDialog() {
        final EditText editText = new EditText(this);
        editText.setInputType(InputType.TYPE_CLASS_TEXT);
        editText.setText(nativeGetInputText());
        editText.selectAll();

        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("输入文本");
        builder.setView(editText);
        builder.setPositiveButton("确定", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                String text = editText.getText().toString();
                nativeSetInputText(text);
            }
        });
        builder.setNegativeButton("取消", null);
        builder.show();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        handler.removeCallbacksAndMessages(null);
        windowManager.removeView(glSurfaceView);
        windowManager.removeView(touchView);
        nativeShutdown();
    }

    private class Renderer implements GLSurfaceView.Renderer {
        public void onSurfaceCreated(GL10 gl, EGLConfig c) { nativeInitImGui(); }
        public void onSurfaceChanged(GL10 gl, int w, int h) { nativeResize(w, h); }
        public void onDrawFrame(GL10 gl) { nativeRenderFrame(); }
    }

    private native void nativeInitImGui();
    private native void nativeResize(int w, int h);
    private native void nativeRenderFrame();
    private native void nativeTouchEvent(boolean d, float x, float y);
    private native boolean nativeNeedShowInputDialog();
    private native void nativeSetNeedShowInputDialog(boolean b);
    private native String nativeGetInputText();
    private native void nativeSetInputText(String text);
    private native void nativeShutdown();
    private native void nativeSetConfigPath(String path);
}