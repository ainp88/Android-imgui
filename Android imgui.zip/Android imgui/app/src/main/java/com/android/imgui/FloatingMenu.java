package com.android.imgui;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.graphics.PixelFormat;
import android.opengl.GLSurfaceView;
import android.os.Handler;
import android.os.Looper;
import android.text.InputType;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.EditText;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.Map;
import javax.microedition.khronos.opengles.GL10;
import javax.microedition.khronos.egl.EGLConfig;

public class FloatingMenu {
    private static WindowManager windowManager;
    private static GLSurfaceView glSurfaceView;
    private static View touchView;
    private static WindowManager.LayoutParams touchParams;
    private static Activity sActivity;

    public static void show(final Context context) {
        new Handler(Looper.getMainLooper()).post(new Runnable() {
                    @Override
                    public void run() {
                        Activity activity = null;
                        if (context instanceof Activity) {
                            activity = (Activity) context;
                        } else {
                            activity = getTopActivity();
                            if (activity == null) return;
                        }
                        activity.setTheme(android.R.style.Theme_Material);
                        createOverlay(activity);
                    }
                });
    }

    private static Activity getTopActivity() {
        try {
            Class<?> at = Class.forName("android.app.ActivityThread");
            Method current = at.getDeclaredMethod("currentActivityThread");
            current.setAccessible(true);
            Object atObj = current.invoke(null);
            Field activities = at.getDeclaredField("mActivities");
            activities.setAccessible(true);
            Map<?, ?> map = (Map<?, ?>) activities.get(atObj);
            for (Object record : map.values()) {
                Class<?> ar = record.getClass();
                Field paused = ar.getDeclaredField("paused");
                paused.setAccessible(true);
                if (!paused.getBoolean(record)) {
                    Field activity = ar.getDeclaredField("activity");
                    activity.setAccessible(true);
                    return (Activity) activity.get(record);
                }
            }
        } catch (Throwable ignored) {
        }
        return null;
    }

    private static void showInputDialog() {
        final EditText editText = new EditText(sActivity);
        editText.setInputType(InputType.TYPE_CLASS_TEXT);
        editText.setText(nativeGetInputText());
        editText.selectAll();

        AlertDialog.Builder builder = new AlertDialog.Builder(sActivity);
        builder.setTitle("输入文本");
        builder.setView(editText);
        builder.setPositiveButton("确定", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                String text = editText.getText().toString();
                nativeSetInputText(text);
            }
        });
        builder.setNegativeButton("取消", null);
        builder.show();
    }

    private static void createOverlay(Activity activity) {
        sActivity = activity;
        final WindowManager wm = activity.getWindowManager();

        android.graphics.Point screenSize = new android.graphics.Point();
        wm.getDefaultDisplay().getRealSize(screenSize);
        nativeSetScreenSize(screenSize.x, screenSize.y);
        String configPath = activity.getFilesDir().getAbsolutePath() + "/imguiconfig.cfg";
        nativeSetConfigPath(configPath);

        glSurfaceView = new GLSurfaceView(activity);
        glSurfaceView.setEGLConfigChooser(8, 8, 8, 8, 16, 0);
        glSurfaceView.getHolder().setFormat(PixelFormat.TRANSLUCENT);
        glSurfaceView.setEGLContextClientVersion(3);
        glSurfaceView.setRenderer(new ImGuiRenderer());
        glSurfaceView.setRenderMode(GLSurfaceView.RENDERMODE_CONTINUOUSLY);
        glSurfaceView.setZOrderOnTop(true);

        WindowManager.LayoutParams glParams = new WindowManager.LayoutParams(
        WindowManager.LayoutParams.MATCH_PARENT,
        WindowManager.LayoutParams.MATCH_PARENT,
        WindowManager.LayoutParams.TYPE_APPLICATION,
        WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE |
                WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE |
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN |
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
        PixelFormat.TRANSLUCENT
        );
        glParams.gravity = Gravity.TOP | Gravity.LEFT;
        wm.addView(glSurfaceView, glParams);

        touchView = new View(activity);
        touchParams = new WindowManager.LayoutParams(
        WindowManager.LayoutParams.WRAP_CONTENT,
        WindowManager.LayoutParams.WRAP_CONTENT,
        WindowManager.LayoutParams.TYPE_APPLICATION,
        WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE |
                WindowManager.LayoutParams.FLAG_SPLIT_TOUCH |
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN |
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
        PixelFormat.TRANSLUCENT
        );
        touchParams.gravity = Gravity.TOP | Gravity.LEFT;
        touchParams.x = 0;
        touchParams.y = 0;
        wm.addView(touchView, touchParams);

        touchView.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent e) {
                int a = e.getActionMasked();
                boolean down = (a == MotionEvent.ACTION_DOWN ||
                        a == MotionEvent.ACTION_POINTER_DOWN ||
                        a == MotionEvent.ACTION_MOVE);
                nativeTouchEvent(down, e.getRawX(), e.getRawY());
                return true;
            }
        });

        final Handler handler = new Handler(Looper.getMainLooper());
        handler.postDelayed(new Runnable() {
            @Override
            public void run() {
                try {
                    String rect = nativeGetWindowRect();
                    if (rect != null && !rect.isEmpty()) {
                        String[] parts = rect.split("\\|");
                        if (parts.length == 4) {
                            touchParams.x = Integer.parseInt(parts[0]);
                            touchParams.y = Integer.parseInt(parts[1]);
                            touchParams.width = Integer.parseInt(parts[2]);
                            touchParams.height = Integer.parseInt(parts[3]);
                            wm.updateViewLayout(touchView, touchParams);
                        }
                    }
                } catch (Exception ignored) {
                }
                handler.postDelayed(this, 50);
            }
        }, 50);

        final Handler inputHandler = new Handler(Looper.getMainLooper());
        inputHandler.postDelayed(new Runnable() {
            @Override
            public void run() {
                if (nativeNeedShowInputDialog()) {
                    nativeSetNeedShowInputDialog(false);
                    showInputDialog();
                }
                inputHandler.postDelayed(this, 100);
            }
        }, 100);
    }

    private static class ImGuiRenderer implements GLSurfaceView.Renderer {
        @Override
        public void onSurfaceCreated(GL10 gl, EGLConfig config) {
            nativeInitImGui();
        }

        @Override
        public void onSurfaceChanged(GL10 gl, int width, int height) {
            nativeResize(width, height);
        }

        @Override
        public void onDrawFrame(GL10 gl) {
            nativeRenderFrame();
        }
    }

    private static native void nativeInitImGui();

    private static native void nativeResize(int w, int h);

    private static native void nativeRenderFrame();

    private static native void nativeTouchEvent(boolean d, float x, float y);

    private static native String nativeGetWindowRect();

    private static native void nativeSetScreenSize(int w, int h);

    private static native boolean nativeNeedShowInputDialog();

    private static native void nativeSetNeedShowInputDialog(boolean b);

    private static native String nativeGetInputText();

    private static native void nativeSetInputText(String text);

    private static native void nativeSetConfigPath(String path);
}