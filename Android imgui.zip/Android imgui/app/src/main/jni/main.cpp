#include <jni.h>
#include <android/log.h>
#include <EGL/egl.h>
#include <GLES3/gl3.h>
#include <string>
#include <cstdio>
#include <cmath>
#include <cstring>
#include <vector>
#include <cctype>
#include <thread>
#include <chrono>

#include "imgui/imgui.h"
#include "imgui/imgui_internal.h"
#include "imgui/backends/imgui_impl_opengl3.h"
#include "imgui/ttf.h"
#include "obfuscate.h"

#ifdef USE_DEX
#include "dex.h"
#endif

#define LOG_TAG "ImGuiMenu"
#define LOGI(...) ((void)0)

extern const unsigned int OPPOSans_H[];
extern const unsigned int OPPOSans_H_size;

static int screenWidth = 0;
static int screenHeight = 0;
static int g_ScreenWidth = 0;
static int g_ScreenHeight = 0;
static bool g_Initialized = false;
static bool g_Shutdown = false;
static bool g_IsInjected = false;

static bool Feature1 = false;
static bool Feature2 = false;
static bool Feature3 = false;
static float SliderValue = 0.5f;
static int ComboSelected = 0;
static char InputText[256] = "你好";
static char InputText2[256] = "世界";
static bool ShowMenu = true;
static bool ShowDemoWindow = false;
static bool ShowAnotherWindow = false;
static float ColorEdit[3] = {0.5f, 0.2f, 0.8f};
static int Counter = 0;

static float ContentScale = 3.0f;
static float LastContentScale = 3.0f;
static int ThemeIndex = 1;
static int LastThemeIndex = 1;

static float g_TouchX = 0;
static float g_TouchY = 0;
static bool  g_TouchDown = false;

static bool g_NeedShowInputDialog = false;
static char* g_ActiveInputBuffer = nullptr;
static size_t g_ActiveInputBufSize = 0;

static PFNGLBINDVERTEXARRAYPROC  p_glBindVertexArray = nullptr;
static PFNGLDELETEVERTEXARRAYSPROC p_glDeleteVertexArrays = nullptr;
static PFNGLGENVERTEXARRAYSPROC p_glGenVertexArrays = nullptr;
static PFNGLBINDSAMPLERPROC p_glBindSampler = nullptr;
static PFNGLDELETESAMPLERSPROC p_glDeleteSamplers = nullptr;
static PFNGLGENSAMPLERSPROC p_glGenSamplers = nullptr;

extern "C" {
    void glBindVertexArray(GLuint a) { if(p_glBindVertexArray) p_glBindVertexArray(a); }
    void glDeleteVertexArrays(GLsizei n, const GLuint* a) { if(p_glDeleteVertexArrays) p_glDeleteVertexArrays(n,a); }
    void glGenVertexArrays(GLsizei n, GLuint* a) { if(p_glGenVertexArrays) p_glGenVertexArrays(n,a); }
    void glBindSampler(GLuint u, GLuint s) { if(p_glBindSampler) p_glBindSampler(u,s); }
    void glDeleteSamplers(GLsizei n, const GLuint* a) { if(p_glDeleteSamplers) p_glDeleteSamplers(n,a); }
    void glGenSamplers(GLsizei n, GLuint* a) { if(p_glGenSamplers) p_glGenSamplers(n,a); }
}

static void LoadGLES3Functions() {
    p_glBindVertexArray = (PFNGLBINDVERTEXARRAYPROC)eglGetProcAddress(OBFUSCATE("glBindVertexArray"));
    p_glDeleteVertexArrays = (PFNGLDELETEVERTEXARRAYSPROC)eglGetProcAddress(OBFUSCATE("glDeleteVertexArrays"));
    p_glGenVertexArrays = (PFNGLGENVERTEXARRAYSPROC)eglGetProcAddress(OBFUSCATE("glGenVertexArrays"));
    p_glBindSampler = (PFNGLBINDSAMPLERPROC)eglGetProcAddress(OBFUSCATE("glBindSampler"));
    p_glDeleteSamplers = (PFNGLDELETESAMPLERSPROC)eglGetProcAddress(OBFUSCATE("glDeleteSamplers"));
    p_glGenSamplers = (PFNGLGENSAMPLERSPROC)eglGetProcAddress(OBFUSCATE("glGenSamplers"));
}

static float GetDPIScale() {
    if (screenWidth <= 0 || screenHeight <= 0) return 1.0f;
    float sX = (float)screenWidth / 1080.0f;
    float sY = (float)screenHeight / 1920.0f;
    float s = fminf(sX, sY);
    return s < 0.8f ? 0.8f : s;
}

static const ImWchar ChineseRanges[] = {
    0x0020, 0x00FF, 0x2000, 0x206F, 0x3000, 0x30FF,
    0x4E00, 0x9FFF, 0xFF00, 0xFFEF, 0,
};

static void LoadChineseFont() {
    ImGuiIO& io = ImGui::GetIO();
    ImFontConfig cfg;
    cfg.FontDataOwnedByAtlas = false;
    float fontSize = 18.0f * GetDPIScale();
    io.Fonts->AddFontFromMemoryTTF((void*)OPPOSans_H, (int)OPPOSans_H_size, fontSize, &cfg, ChineseRanges);
}

static void ApplyTheme() {
    switch (ThemeIndex) {
        case 0: ImGui::StyleColorsClassic(); break;
        case 1: ImGui::StyleColorsDark();    break;
        case 2: ImGui::StyleColorsLight();   break;
        default: ImGui::StyleColorsDark();   break;
    }
}

static void ApplyScale() {
    bool themeChanged = (LastThemeIndex != ThemeIndex);
    if (LastContentScale == ContentScale && !themeChanged) return;
    LastContentScale = ContentScale;
    LastThemeIndex = ThemeIndex;
    float dpi = GetDPIScale();
    float eff = dpi;
    ImGui::GetIO().FontGlobalScale = eff * ContentScale;
    ImGuiStyle& s = ImGui::GetStyle();
    s = ImGuiStyle();
    ApplyTheme();
    s.TouchExtraPadding = ImVec2(1, 1);
    s.GrabMinSize = 15.0f;
    s.WindowMinSize = ImVec2(5, 5);
    s.ScaleAllSizes(eff * ContentScale);
}

static void MyInputText(const char* label, char* buf, size_t buf_size) {
    ImGui::InputText(label, buf, buf_size, ImGuiInputTextFlags_ReadOnly);
    if (ImGui::IsItemClicked()) {
        g_ActiveInputBuffer = buf;
        g_ActiveInputBufSize = buf_size;
        g_NeedShowInputDialog = true;
    }
}

static std::string g_ConfigPath;

static void SaveConfig() {
    if (g_ConfigPath.empty()) return;
    FILE* f = fopen(g_ConfigPath.c_str(), OBFUSCATE("w"));
    if (!f) return;
    fprintf(f, OBFUSCATE("%d\n%d\n%d\n%f\n%d\n%f\n%d\n%s\n%s\n"),
        Feature1, Feature2, Feature3, SliderValue, ComboSelected,
        ContentScale, ThemeIndex, InputText, InputText2);
    fclose(f);
}

static void LoadConfig() {
    if (g_ConfigPath.empty()) return;
    FILE* f = fopen(g_ConfigPath.c_str(), OBFUSCATE("r"));
    if (!f) return;
    int f1, f2, f3, cs, ti;
    float sv, ct;
    fscanf(f, OBFUSCATE("%d\n%d\n%d\n%f\n%d\n%f\n%d\n"),
        &f1, &f2, &f3, &sv, &cs, &ct, &ti);
    Feature1 = f1; Feature2 = f2; Feature3 = f3;
    SliderValue = sv; ComboSelected = cs;
    ContentScale = ct; ThemeIndex = ti;
    fscanf(f, OBFUSCATE("%255[^\n]\n%255[^\n]"), InputText, InputText2);
    fclose(f);
}

static void DrawMenu() {
    ApplyScale();
    float dpi = GetDPIScale();
    float eff = dpi;

    if (!ShowMenu) {
        ImGui::Begin(OBFUSCATE("##Toggle"), nullptr,
            ImGuiWindowFlags_NoTitleBar | ImGuiWindowFlags_NoResize |
            ImGuiWindowFlags_NoCollapse | ImGuiWindowFlags_NoMove |
            ImGuiWindowFlags_NoScrollbar | ImGuiWindowFlags_AlwaysAutoResize);
        if (ImGui::Button(OBFUSCATE("打开"), ImVec2(150 * eff * ContentScale, 40 * eff * ContentScale))) ShowMenu = true;
        ImGui::End();
        return;
    }

    ImGui::Begin(OBFUSCATE("菜单"), nullptr, ImGuiWindowFlags_MenuBar);

    if (ImGui::BeginMenuBar()) {
        if (ImGui::BeginMenu(OBFUSCATE("文件"))) {
            if (ImGui::MenuItem(OBFUSCATE("隐藏"))) ShowMenu = false;
            if (ImGui::MenuItem(OBFUSCATE("退出"))) g_Shutdown = true;
            ImGui::EndMenu();
        }
        if (ImGui::BeginMenu(OBFUSCATE("视图"))) {
            ImGui::MenuItem(OBFUSCATE("演示窗口"), nullptr, &ShowDemoWindow);
            ImGui::MenuItem(OBFUSCATE("额外窗口"), nullptr, &ShowAnotherWindow);
            ImGui::Separator();
            if (ImGui::BeginMenu(OBFUSCATE("主题"))) {
                if (ImGui::MenuItem(OBFUSCATE("经典"), nullptr, ThemeIndex == 0)) ThemeIndex = 0;
                if (ImGui::MenuItem(OBFUSCATE("深色"), nullptr, ThemeIndex == 1)) ThemeIndex = 1;
                if (ImGui::MenuItem(OBFUSCATE("浅色"), nullptr, ThemeIndex == 2)) ThemeIndex = 2;
                ImGui::EndMenu();
            }
            ImGui::EndMenu();
        }
        ImGui::EndMenuBar();
    }

    if (ImGui::BeginTabBar(OBFUSCATE("T"))) {
        if (ImGui::BeginTabItem(OBFUSCATE("功能"))) {
            ImGui::Checkbox(OBFUSCATE("功能 1"), &Feature1);
            ImGui::Checkbox(OBFUSCATE("功能 2"), &Feature2);
            ImGui::Checkbox(OBFUSCATE("功能 3"), &Feature3);
            ImGui::Separator();
            if (ImGui::Button(OBFUSCATE("全开"))) Feature1 = Feature2 = Feature3 = true;
            ImGui::SameLine();
            if (ImGui::Button(OBFUSCATE("全关"))) Feature1 = Feature2 = Feature3 = false;
            ImGui::SameLine();
            if (ImGui::Button(OBFUSCATE("切换"))) { Feature1=!Feature1; Feature2=!Feature2; Feature3=!Feature3; }
            ImGui::EndTabItem();
        }
        if (ImGui::BeginTabItem(OBFUSCATE("设置"))) {
            ImGui::SliderFloat(OBFUSCATE("缩放"), &ContentScale, 1.0f, 5.0f, OBFUSCATE("%.1f"));
            ImGui::Separator();
            ImGui::SliderFloat(OBFUSCATE("数值"), &SliderValue, 0, 1);
            ImGui::Separator();
            const char* items[] = {OBFUSCATE("选项A"), OBFUSCATE("选项B"), OBFUSCATE("选项C"), OBFUSCATE("选项D")};
            ImGui::Combo(OBFUSCATE("下拉"), &ComboSelected, items, IM_ARRAYSIZE(items));
            MyInputText(OBFUSCATE("输入1"), InputText, IM_ARRAYSIZE(InputText));
            MyInputText(OBFUSCATE("输入2"), InputText2, IM_ARRAYSIZE(InputText2));
            ImGui::ColorEdit3(OBFUSCATE("颜色"), ColorEdit);
            ImGui::Separator();
            if (ImGui::Button(OBFUSCATE("保存设置"), ImVec2(-1, 0))) { SaveConfig(); }
            ImGui::EndTabItem();
        }
        if (ImGui::BeginTabItem(OBFUSCATE("计数"))) {
            ImGui::Text(OBFUSCATE("计数: %d"), Counter);
            if (ImGui::Button(OBFUSCATE("+"), ImVec2(-1, 0))) Counter++;
            if (ImGui::Button(OBFUSCATE("归零"), ImVec2(-1, 0))) Counter = 0;
            ImGui::EndTabItem();
        }
        ImGui::EndTabBar();
    }
    ImGui::End();

    if (ShowAnotherWindow) { ImGui::Begin(OBFUSCATE("额外窗口"), &ShowAnotherWindow); ImGui::Text(OBFUSCATE("计数: %d"), Counter); ImGui::End(); }
    if (ShowDemoWindow) ImGui::ShowDemoWindow(&ShowDemoWindow);
}

extern "C" {

// ============== MainActivity（调试用）==============
JNIEXPORT void JNICALL
Java_com_android_imgui_MainActivity_nativeInitImGui(JNIEnv* e, jobject o) {
    g_IsInjected = false;
    if (g_Initialized) return;
    LoadGLES3Functions();
    IMGUI_CHECKVERSION();
    ImGui::CreateContext();
    ImGuiIO& io = ImGui::GetIO();
    io.IniFilename = nullptr;
    LastContentScale = -1;
    LastThemeIndex = -1;
    ApplyScale();
    ImGui_ImplOpenGL3_Init(OBFUSCATE("#version 300 es"));
    LoadChineseFont();
    g_Initialized = true;
}

JNIEXPORT void JNICALL
Java_com_android_imgui_MainActivity_nativeResize(JNIEnv* e, jobject o, jint w, jint h) {
    screenWidth = w; screenHeight = h;
    ImGuiIO& io = ImGui::GetIO();
    io.DisplaySize = ImVec2((float)w, (float)h);
    io.DisplayFramebufferScale = ImVec2(1, 1);
    LastContentScale = -1;
    LastThemeIndex = -1;
}

JNIEXPORT void JNICALL
Java_com_android_imgui_MainActivity_nativeRenderFrame(JNIEnv* e, jobject o) {
    if (!g_Initialized || g_Shutdown) return;
    if (screenWidth <= 0 || screenHeight <= 0) return;
    ImGuiIO& io = ImGui::GetIO();
    io.MousePos = ImVec2(g_TouchX, g_TouchY);
    io.MouseDown[0] = g_TouchDown;
    ImGui_ImplOpenGL3_NewFrame(); ImGui::NewFrame();
    DrawMenu();
    ImGui::Render();
    glViewport(0, 0, screenWidth, screenHeight);
    glClearColor(0, 0, 0, 0); glClear(GL_COLOR_BUFFER_BIT);
    ImGui_ImplOpenGL3_RenderDrawData(ImGui::GetDrawData());
}

JNIEXPORT void JNICALL
Java_com_android_imgui_MainActivity_nativeTouchEvent(JNIEnv* e, jobject o, jboolean d, jfloat x, jfloat y) {
    g_TouchX = x;
    g_TouchY = y;
    g_TouchDown = d;
}

JNIEXPORT jboolean JNICALL
Java_com_android_imgui_MainActivity_nativeWantCaptureMouse(JNIEnv* e, jobject o) {
    if (g_Initialized) {
        return ImGui::GetIO().WantCaptureMouse ? JNI_TRUE : JNI_FALSE;
    }
    return JNI_FALSE;
}

JNIEXPORT jboolean JNICALL
Java_com_android_imgui_MainActivity_nativeNeedShowInputDialog(JNIEnv* e, jobject o) {
    return g_NeedShowInputDialog;
}

JNIEXPORT void JNICALL
Java_com_android_imgui_MainActivity_nativeSetNeedShowInputDialog(JNIEnv* e, jobject o, jboolean b) {
    g_NeedShowInputDialog = b;
}

JNIEXPORT jstring JNICALL
Java_com_android_imgui_MainActivity_nativeGetInputText(JNIEnv* e, jobject o) {
    if (g_ActiveInputBuffer) return e->NewStringUTF(g_ActiveInputBuffer);
    return e->NewStringUTF("");
}

JNIEXPORT void JNICALL
Java_com_android_imgui_MainActivity_nativeSetInputText(JNIEnv* e, jobject o, jstring text) {
    if (g_ActiveInputBuffer) {
        const char* str = e->GetStringUTFChars(text, nullptr);
        strncpy(g_ActiveInputBuffer, str, g_ActiveInputBufSize - 1);
        g_ActiveInputBuffer[g_ActiveInputBufSize - 1] = '\0';
        e->ReleaseStringUTFChars(text, str);
    }
    g_ActiveInputBuffer = nullptr;
    g_ActiveInputBufSize = 0;
}

JNIEXPORT void JNICALL
Java_com_android_imgui_MainActivity_nativeShutdown(JNIEnv* e, jobject o) {
    if (!g_Initialized) return;
    SaveConfig();
    ImGui_ImplOpenGL3_Shutdown(); ImGui::DestroyContext();
    g_Initialized = false;
}

JNIEXPORT void JNICALL
Java_com_android_imgui_MainActivity_nativeSetConfigPath(JNIEnv* e, jobject o, jstring path) {
    const char* str = e->GetStringUTFChars(path, nullptr);
    g_ConfigPath = str;
    e->ReleaseStringUTFChars(path, str);
    LoadConfig();
}

// ============== FloatingMenu（注入用）==============
#ifdef USE_DEX
JNIEXPORT void JNICALL
Java_com_android_imgui_FloatingMenu_nativeSetScreenSize(JNIEnv* e, jclass cls, jint w, jint h) {
    g_ScreenWidth = w;
    g_ScreenHeight = h;
}

JNIEXPORT void JNICALL
Java_com_android_imgui_FloatingMenu_nativeSetConfigPath(JNIEnv* e, jclass cls, jstring path) {
    const char* str = e->GetStringUTFChars(path, nullptr);
    g_ConfigPath = str;
    e->ReleaseStringUTFChars(path, str);
    LoadConfig();
}

JNIEXPORT void JNICALL
Java_com_android_imgui_FloatingMenu_nativeInitImGui(JNIEnv* e, jclass cls) {
    if (g_Initialized) return;
    LoadGLES3Functions();
    IMGUI_CHECKVERSION();
    ImGui::CreateContext();
    ImGuiIO& io = ImGui::GetIO();
    io.IniFilename = nullptr;
    if (g_ScreenWidth > 0 && g_ScreenHeight > 0) {
        io.DisplaySize = ImVec2((float)g_ScreenWidth, (float)g_ScreenHeight);
    }
    io.DisplayFramebufferScale = ImVec2(1, 1);
    LastContentScale = -1;
    LastThemeIndex = -1;
    ApplyScale();
    ImGui_ImplOpenGL3_Init(OBFUSCATE("#version 300 es"));
    LoadChineseFont();
    g_Initialized = true;
}

JNIEXPORT void JNICALL
Java_com_android_imgui_FloatingMenu_nativeResize(JNIEnv* e, jclass cls, jint w, jint h) {
    screenWidth = w;
    screenHeight = h;
    LastContentScale = -1;
    LastThemeIndex = -1;
}

JNIEXPORT void JNICALL
Java_com_android_imgui_FloatingMenu_nativeRenderFrame(JNIEnv* e, jclass cls) {
    if (!g_Initialized || g_Shutdown) return;
    if (screenWidth <= 0 || screenHeight <= 0) return;
    ImGuiIO& io = ImGui::GetIO();
    io.MousePos = ImVec2(g_TouchX, g_TouchY);
    io.MouseDown[0] = g_TouchDown;
    ImGui_ImplOpenGL3_NewFrame(); ImGui::NewFrame();
    DrawMenu();
    ImGui::Render();
    glViewport(0, 0, screenWidth, screenHeight);
    glClearColor(0, 0, 0, 0); glClear(GL_COLOR_BUFFER_BIT);
    ImGui_ImplOpenGL3_RenderDrawData(ImGui::GetDrawData());
}

JNIEXPORT void JNICALL
Java_com_android_imgui_FloatingMenu_nativeTouchEvent(JNIEnv* e, jclass cls, jboolean d, jfloat x, jfloat y) {
    g_TouchX = x;
    g_TouchY = y;
    g_TouchDown = d;
}

JNIEXPORT jstring JNICALL
Java_com_android_imgui_FloatingMenu_nativeGetWindowRect(JNIEnv* e, jclass cls) {
    static char cachedResult[128] = "0|0|0|0";

    if (!g_Initialized) return e->NewStringUTF(cachedResult);

    ImGuiContext* ctx = ImGui::GetCurrentContext();
    if (!ctx) return e->NewStringUTF(cachedResult);

    int hash = 0;
    for (ImGuiWindow* win : ctx->Windows) {
        if (win->WasActive && !win->Hidden && win->Size.x > 0 && win->Size.y > 0) {
            hash += (int)win->Pos.x + (int)win->Pos.y * 1000 + (int)win->Size.x * 1000000 + (int)win->Size.y * 1000000000;
        }
    }

    static int lastHash = 0;
    if (hash == lastHash) return e->NewStringUTF(cachedResult);
    lastHash = hash;

    float minX = 99999, minY = 99999, maxX = -99999, maxY = -99999;
    bool found = false;

    for (ImGuiWindow* win : ctx->Windows) {
        if (win->WasActive && !win->Hidden && win->Size.x > 0 && win->Size.y > 0) {
            float x1 = win->Pos.x;
            float y1 = win->Pos.y;
            float x2 = win->Pos.x + win->Size.x;
            float y2 = win->Pos.y + win->Size.y;

            if (x1 < minX) minX = x1;
            if (y1 < minY) minY = y1;
            if (x2 > maxX) maxX = x2;
            if (y2 > maxY) maxY = y2;
            found = true;
        }
    }

    if (found) {
        sprintf(cachedResult, OBFUSCATE("%d|%d|%d|%d"),
            (int)minX, (int)minY,
            (int)(maxX - minX), (int)(maxY - minY));
    }

    return e->NewStringUTF(cachedResult);
}

JNIEXPORT jboolean JNICALL
Java_com_android_imgui_FloatingMenu_nativeNeedShowInputDialog(JNIEnv* e, jclass cls) {
    return g_NeedShowInputDialog;
}

JNIEXPORT void JNICALL
Java_com_android_imgui_FloatingMenu_nativeSetNeedShowInputDialog(JNIEnv* e, jclass cls, jboolean b) {
    g_NeedShowInputDialog = b;
}

JNIEXPORT jstring JNICALL
Java_com_android_imgui_FloatingMenu_nativeGetInputText(JNIEnv* e, jclass cls) {
    if (g_ActiveInputBuffer) return e->NewStringUTF(g_ActiveInputBuffer);
    return e->NewStringUTF("");
}

JNIEXPORT void JNICALL
Java_com_android_imgui_FloatingMenu_nativeSetInputText(JNIEnv* e, jclass cls, jstring text) {
    if (g_ActiveInputBuffer) {
        const char* str = e->GetStringUTFChars(text, nullptr);
        strncpy(g_ActiveInputBuffer, str, g_ActiveInputBufSize - 1);
        g_ActiveInputBuffer[g_ActiveInputBufSize - 1] = '\0';
        e->ReleaseStringUTFChars(text, str);
    }
    g_ActiveInputBuffer = nullptr;
    g_ActiveInputBufSize = 0;
}
#endif

} // extern "C"

#ifdef USE_DEX
static JavaVM* g_VM = nullptr;

static jobjectArray HexToByteBufferArray(JNIEnv* env, const std::string& hex) {
    int len = hex.length() / 2;
    jbyteArray arr = env->NewByteArray(len);
    jbyte* buf = env->GetByteArrayElements(arr, nullptr);
    for (int i = 0; i < len; i++) {
        char h = hex[i * 2];
        char l = hex[i * 2 + 1];
        int hi = isdigit(h) ? h - '0' : tolower(h) - 'a' + 10;
        int lo = isdigit(l) ? l - '0' : tolower(l) - 'a' + 10;
        buf[i] = (jbyte)((hi << 4) | lo);
    }
    env->ReleaseByteArrayElements(arr, buf, 0);
    jclass bbCls = env->FindClass(OBFUSCATE("java/nio/ByteBuffer"));
    jmethodID wrap = env->GetStaticMethodID(bbCls, OBFUSCATE("wrap"), OBFUSCATE("([B)Ljava/nio/ByteBuffer;"));
    jobject bb = env->CallStaticObjectMethod(bbCls, wrap, arr);
    return env->NewObjectArray(1, bbCls, bb);
}

static void LoadDexAndShowMenu(JNIEnv* env, jobject context) {
    std::string hexStr(hexdex);
    jobjectArray buffers = HexToByteBufferArray(env, hexStr);
    if (!buffers) return;

    jclass classLoaderClass = env->FindClass(OBFUSCATE("java/lang/ClassLoader"));
    jmethodID getSystemClassLoader = env->GetStaticMethodID(classLoaderClass, OBFUSCATE("getSystemClassLoader"), OBFUSCATE("()Ljava/lang/ClassLoader;"));
    jobject parentCl = env->CallStaticObjectMethod(classLoaderClass, getSystemClassLoader);

    jclass imCls = env->FindClass(OBFUSCATE("dalvik/system/InMemoryDexClassLoader"));
    if (!imCls) return;

    jmethodID ctor = env->GetMethodID(imCls, OBFUSCATE("<init>"), OBFUSCATE("([Ljava/nio/ByteBuffer;Ljava/lang/ClassLoader;)V"));
    jobject dexLoader = env->NewObject(imCls, ctor, buffers, parentCl);

    jmethodID loadClass = env->GetMethodID(imCls, OBFUSCATE("loadClass"), OBFUSCATE("(Ljava/lang/String;)Ljava/lang/Class;"));
    jstring clsName = env->NewStringUTF(OBFUSCATE("com.android.imgui.FloatingMenu"));
    jclass menuClass = (jclass)env->CallObjectMethod(dexLoader, loadClass, clsName);
    if (!menuClass) { env->ExceptionClear(); return; }

    JNINativeMethod methods[] = {
        {OBFUSCATE("nativeInitImGui"),            OBFUSCATE("()V"),                   (void*)Java_com_android_imgui_FloatingMenu_nativeInitImGui},
        {OBFUSCATE("nativeResize"),               OBFUSCATE("(II)V"),                 (void*)Java_com_android_imgui_FloatingMenu_nativeResize},
        {OBFUSCATE("nativeRenderFrame"),          OBFUSCATE("()V"),                   (void*)Java_com_android_imgui_FloatingMenu_nativeRenderFrame},
        {OBFUSCATE("nativeTouchEvent"),           OBFUSCATE("(ZFF)V"),                (void*)Java_com_android_imgui_FloatingMenu_nativeTouchEvent},
        {OBFUSCATE("nativeGetWindowRect"),        OBFUSCATE("()Ljava/lang/String;"),  (void*)Java_com_android_imgui_FloatingMenu_nativeGetWindowRect},
        {OBFUSCATE("nativeSetScreenSize"),        OBFUSCATE("(II)V"),                 (void*)Java_com_android_imgui_FloatingMenu_nativeSetScreenSize},
        {OBFUSCATE("nativeSetConfigPath"),        OBFUSCATE("(Ljava/lang/String;)V"), (void*)Java_com_android_imgui_FloatingMenu_nativeSetConfigPath},
        {OBFUSCATE("nativeNeedShowInputDialog"),  OBFUSCATE("()Z"),                   (void*)Java_com_android_imgui_FloatingMenu_nativeNeedShowInputDialog},
        {OBFUSCATE("nativeSetNeedShowInputDialog"),OBFUSCATE("(Z)V"),                 (void*)Java_com_android_imgui_FloatingMenu_nativeSetNeedShowInputDialog},
        {OBFUSCATE("nativeGetInputText"),         OBFUSCATE("()Ljava/lang/String;"),  (void*)Java_com_android_imgui_FloatingMenu_nativeGetInputText},
        {OBFUSCATE("nativeSetInputText"),         OBFUSCATE("(Ljava/lang/String;)V"), (void*)Java_com_android_imgui_FloatingMenu_nativeSetInputText},
    };
    env->RegisterNatives(menuClass, methods, 11);

    jmethodID showMethod = env->GetStaticMethodID(menuClass, OBFUSCATE("show"), OBFUSCATE("(Landroid/content/Context;)V"));
    if (!showMethod) return;
    env->CallStaticVoidMethod(menuClass, showMethod, context);
}

static void binJava() {
    JNIEnv* env;
    if (g_VM->AttachCurrentThread(&env, nullptr) != JNI_OK) return;

    jclass atCls = env->FindClass(OBFUSCATE("android/app/ActivityThread"));
    if (!atCls) return;

    jmethodID curApp = env->GetStaticMethodID(atCls, OBFUSCATE("currentApplication"), OBFUSCATE("()Landroid/app/Application;"));
    jobject app = env->CallStaticObjectMethod(atCls, curApp);
    if (!app) return;

    LoadDexAndShowMenu(env, app);
}
#endif

JNIEXPORT jint JNI_OnLoad(JavaVM* vm, void*) {
    g_IsInjected = true;
#ifdef USE_DEX
    g_VM = vm;
    std::thread([]{
        std::this_thread::sleep_for(std::chrono::milliseconds(500));
        if (g_IsInjected && !g_Initialized) {
            binJava();
        }
    }).detach();
#endif
    return JNI_VERSION_1_6;
}